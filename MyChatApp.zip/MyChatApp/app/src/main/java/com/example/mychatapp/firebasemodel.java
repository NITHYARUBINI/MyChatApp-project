package com.example.mychatapp;

public class firebasemodel {

    String username;
    String imageUri;
    String userUID;
    String status;


    public firebasemodel(String username, String imageUri, String userUID, String status) {
        this.username = username;
        this.imageUri = imageUri;
        this.userUID = userUID;
        this.status = status;
    }

    public firebasemodel() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    public String getUserUID() {
        return userUID;
    }

    public void setUserUID(String userUID) {
        this.userUID = userUID;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
