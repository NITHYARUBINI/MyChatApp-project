package com.example.mychatapp;



public class userprofile {


    public String username;
    public String userUID;
    public String imageUri;
    public String status;

    public userprofile() {
    }

    public userprofile(String username, String userUID, String imageUri, String status) {
        this.username = username;
        this.userUID = userUID;
        this.imageUri = imageUri;
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserUID() {
        return userUID;
    }

    public void setUserUID(String userUID) {
        this.userUID = userUID;
    }

    public String getImageUri() {
        return imageUri;
    }

    public void setImageUri(String imageUri) {
        this.imageUri = imageUri;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
